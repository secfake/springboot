package com.tuananh.coursesmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursesManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
