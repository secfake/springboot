package com.tuananh.coursesmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursesManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursesManagementApplication.class, args);
	}

}
